// src/contexts/auth/AuthContext.js
import React, { createContext, useContext } from 'react';
import { useAuth } from '../../hooks/useAuth';

const AuthContext = createContext({
  isAuthenticated: false,
  user: null,
  loading: true,
  login: async () => {},
  logout: async () => {},
  checkAuth: async () => {},
});

export const AuthProvider = ({ children }) => {
  const auth = useAuth();
  return (
    <AuthContext.Provider value={auth}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuthContext = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext deve ser usado dentro de um AuthProvider');
  }
  return context;
};

export const withAuthProvider = (Component) => (props) => (
  <AuthProvider>
    <Component {...props} />
  </AuthProvider>
);
