// hooks/useAuth.js - VERSÃO REVISADA
import { useState, useEffect } from 'react';
import tokenService from '../service/tokenService';

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const verifyAuth = async () => {
      console.log('🔄 useAuth - Iniciando verificação...');
      await checkAuth();
    };

    verifyAuth();

    return () => {
      isMounted = false;
    };
  }, []);

  const checkAuth = async () => {
    try {
      console.log('🔍 useAuth - Verificando token...');
      const token = await tokenService.getToken();
      console.log('📦 useAuth - Token encontrado:', token ? 'SIM' : 'NÃO');

      if (!token) {
        console.log('🚫 useAuth - Nenhum token, usuário NÃO autenticado');
        setIsAuthenticated(false);
        setUser(null);
        return;
      }

      console.log('🔑 useAuth - Token:', token.substring(0, 20) + '...');

      const isExpired = await tokenService.isTokenExpired();
      console.log('⏰ useAuth - Token expirado?', isExpired);

      if (!isExpired) {
        const userData = await tokenService.getUserData();
        console.log('👤 useAuth - Dados do usuário:', userData);
        setIsAuthenticated(true);
        setUser(userData);
      } else {
        console.log('❌ useAuth - Token expirado, limpando dados...');
        await tokenService.clearAuthData();
        setIsAuthenticated(false);
        setUser(null);
      }

    } catch (error) {
      console.error('💥 useAuth - Erro na verificação:', error);
      setIsAuthenticated(false);
      setUser(null);
    } finally {
      console.log('🏁 useAuth - Verificação finalizada');
      setLoading(false);
    }
  };

  const login = async (token) => {
    console.log('🔐 useAuth - Fazendo login...');
    await tokenService.setAuthData(token);
    const userData = await tokenService.getUserData();
    setIsAuthenticated(true);
    setUser(userData);
    console.log('✅ useAuth - Login realizado');
  };

  const logout = async () => {
    console.log('🚪 useAuth - Fazendo logout...');
    setIsAuthenticated(false);
    setUser(null);
    await tokenService.clearAuthData();
    console.log('✅ useAuth - Logout realizado e storage limpo');
  };

  return {
    isAuthenticated,
    user,
    loading,
    checkAuth,
    login,
    logout,
  };
};
