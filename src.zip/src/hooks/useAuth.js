import { useState, useEffect } from 'react';
import tokenService from '../service/tokenService';

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const authenticated = await tokenService.isAuthenticated();
      setIsAuthenticated(authenticated);
      
      if (authenticated) {
        const userData = await tokenService.getUserData();
        setUser(userData);
      }
    } catch (error) {
      console.error('Erro ao verificar autenticação:', error);
      setIsAuthenticated(false);
    } finally {
      setLoading(false);
    }
  };

  const login = async (token) => {
    await tokenService.setAuthData(token);
    setIsAuthenticated(true);
    const userData = await tokenService.getUserData();
    setUser(userData);
  };

  const logout = async () => {
    await tokenService.clearAuthData();
    setIsAuthenticated(false);
    setUser(null);
  };

  return { 
    isAuthenticated, 
    user, 
    loading, 
    checkAuth,
    login,
    logout
  };
};