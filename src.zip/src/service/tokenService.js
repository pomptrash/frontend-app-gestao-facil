import AsyncStorage from '@react-native-async-storage/async-storage';

export const tokenService = {
  // Salvar token e dados do usuário
  setAuthData: async (token, userData = {}) => {
    try {
      await AsyncStorage.setItem('userToken', token);
      
      // Decodificar o token para obter dados adicionais
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (payload.email) {
          await AsyncStorage.setItem('userEmail', payload.email);
        }
        if (payload.cargo) {
          await AsyncStorage.setItem('userRole', payload.cargo);
        }
        if (payload.id) {
          await AsyncStorage.setItem('userId', payload.id.toString());
        }
      } catch (decodeError) {
        console.log('Erro ao decodificar token:', decodeError);
      }
      
      // Salvar dados adicionais se fornecidos
      if (userData.email) {
        await AsyncStorage.setItem('userEmail', userData.email);
      }
    } catch (error) {
      console.error('Erro ao salvar dados de autenticação:', error);
      throw error;
    }
  },

  // Obter token
  getToken: async () => {
    try {
      return await AsyncStorage.getItem('userToken');
    } catch (error) {
      console.error('Erro ao obter token:', error);
      return null;
    }
  },

  // Obter dados do usuário do token
  getUserData: async () => {
    try {
      const token = await AsyncStorage.getItem('userToken');
      if (!token) return null;

      // Decodificar o token JWT
      const payload = JSON.parse(atob(token.split('.')[1]));
      
      return {
        id: payload.id,
        email: payload.email,
        cargo: payload.cargo,
        exp: payload.exp
      };
    } catch (error) {
      console.error('Erro ao obter dados do usuário:', error);
      return null;
    }
  },

  // Verificar se token está expirado
  isTokenExpired: async () => {
    try {
      const userData = await tokenService.getUserData();
      if (!userData || !userData.exp) return true;
      
      const now = Date.now() / 1000;
      return userData.exp < now;
    } catch (error) {
      console.error('Erro ao verificar token:', error);
      return true;
    }
  },

  // Remover todos os dados (logout)
  clearAuthData: async () => {
    try {
      await AsyncStorage.multiRemove([
        'userToken', 
        'userEmail', 
        'userRole', 
        'userId'
      ]);
    } catch (error) {
      console.error('Erro ao limpar dados de autenticação:', error);
      throw error;
    }
  },

  // Verificar se usuário está autenticado
  isAuthenticated: async () => {
    const token = await tokenService.getToken();
    if (!token) return false;
    
    return !(await tokenService.isTokenExpired());
  }
};

export default tokenService;