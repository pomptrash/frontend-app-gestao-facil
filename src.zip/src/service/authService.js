import api from './api';
import tokenService from './tokenService';

export const authService = {
  // 📥 Registro de Usuário
  register: async (userData) => {
    try {
      console.log('Enviando dados para registro:', userData);
      
      const response = await api.post('/auth/register', userData);
      
      console.log('Resposta do registro:', response.data);
      return response.data;
    } catch (error) {
      // Tratamento específico para os códigos do seu backend
      if (error.response?.status === 400) {
        throw new Error('As senhas não coincidem');
      } else if (error.response?.status === 409) {
        throw new Error('E-mail já cadastrado');
      } else {
        const message = error.response?.data?.erro || 
                       error.response?.data?.detalhes || 
                       'Erro ao criar conta. Tente novamente.';
        throw new Error(message);
      }
    }
  },

  // 🔑 Login
  login: async (email, password) => {
    try {
      console.log('Enviando credenciais para login:', { email });
      
      const response = await api.post('/auth/login', { 
        email, 
        password 
      });
      
      console.log('Resposta do login:', response.data);
      
      // Salvar token retornado
      if (response.data.token) {
        await tokenService.setAuthData(response.data.token, {
          email: email
          // O backend não retorna nome e cargo no login, só no token
        });
      }
      
      return response.data;
    } catch (error) {
      // Tratamento específico para os códigos do seu backend
      if (error.response?.status === 401) {
        const backendError = error.response?.data?.erro;
        if (backendError === 'Usuário não encontrado') {
          throw new Error('E-mail não cadastrado');
        } else if (backendError === 'Senha incorreta') {
          throw new Error('Senha incorreta');
        } else {
          throw new Error('E-mail ou senha incorretos');
        }
      } else {
        const message = error.response?.data?.erro || 
                       error.response?.data?.detalhes || 
                       'Erro ao fazer login. Tente novamente.';
        throw new Error(message);
      }
    }
  },

  // 🔒 Rota Protegida - Dados Secretos
  getProtectedData: async () => {
    try {
      const response = await api.post('/auth/dados-secretos');
      return response.data;
    } catch (error) {
      if (error.response?.status === 401) {
        throw new Error('Sessão expirada. Faça login novamente.');
      } else if (error.response?.status === 403) {
        throw new Error('Acesso não autorizado para seu cargo.');
      } else {
        const message = error.response?.data?.message || 
                       'Erro ao acessar dados protegidos';
        throw new Error(message);
      }
    }
  },

  // 🔄 Verificar Token (opcional)
  verifyToken: async () => {
    try {
      const response = await api.get('/auth/verify');
      return response.data;
    } catch (error) {
      throw new Error('Token inválido ou expirado');
    }
  },

  // 👤 Obter dados do usuário do token
  getUserFromToken: async () => {
    try {
      const token = await tokenService.getToken();
      if (!token) {
        throw new Error('Nenhum token encontrado');
      }
      
      // Decodificar o token para obter os dados do usuário
      const payload = JSON.parse(atob(token.split('.')[1]));
      return {
        id: payload.id,
        email: payload.email,
        cargo: payload.cargo
      };
    } catch (error) {
      throw new Error('Erro ao obter dados do usuário: ' + error.message);
    }
  }
};

export default authService;