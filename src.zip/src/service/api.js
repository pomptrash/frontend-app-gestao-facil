import axios from 'axios';
import tokenService from './tokenService';

const API_BASE_URL = 'http://localhost:3000'; // Altere para seu IP local

// ✅ AQUI É ONDE O AXIOS É CONFIGURADO
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token automaticamente
api.interceptors.request.use(
  async (config) => {
    try {
      const token = await tokenService.getToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.log('Erro ao adicionar token:', error);
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Interceptor para tratar respostas
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await tokenService.clearAuthData();
    }
    return Promise.reject(error);
  }
);

export default api;